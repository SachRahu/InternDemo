﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace WebApplication3.Controllers
{
    [Route("api/test")]
    [ApiController]
    public class TestController : ControllerBase
    {

        List<Student> stdList = new List<Student>()
        {
             new Student(){ Id=1, Name="Bill"},
                new Student(){ Id=2, Name="Steve"},
                new Student(){ Id=3, Name="Ram"},
                new Student(){ Id=4, Name="Moin"}
        };

        public class Student
        {
            public int Id { get; set; }
            public string Name { get; set; }
        }

        /// <summary>
        /// Get Student from route
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        [HttpGet("getstudent/{name}")]
        public IActionResult GetId(string name)
        {
            int id = GetStudentId(name);
            if (id == 0)
            {
                return new NotFoundResult();
            }

            return new OkObjectResult(id);
        }

        /// <summary>
        /// getstudent from header value
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet("getstudent")]
        public IActionResult Getstudent([FromHeaderAttribute] int id)
        {
            var result = GetStudentId(id);
            if (result == null)
            {
                return new NotFoundResult();
            }

            return new OkObjectResult(result);
        }

        /// <summary>
        /// Update student 
        /// </summary>
        /// <param name="student"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpPut("updatestudent/{id}")]
        public IActionResult UpdateStudent([FromBody] Student student, int id)
        {
            var result = GetStudentId(id);
            if (result == null)
            {
                return new NotFoundResult();
            }

            result.Name = student.Name;

            return new OkObjectResult(result);
        }

        [HttpPost("save")]
        public IActionResult AddStudent([FromBody] Student student)
        {
            stdList.Add(student);

            return new OkObjectResult(stdList);
        }

        [HttpDelete("delete/{id}")]
        public IActionResult AddStudent(int id)
        {
            var result = GetStudentId(id);
            if (result == null)
            {
                return new NotFoundResult();
            }

            stdList.Remove(result);
            return new OkObjectResult(stdList);
        }

        private int GetStudentId(string name)
        {
            var result = stdList.Where(o => o.Name == name).FirstOrDefault();
            return result.Id;
        }

        private Student GetStudentId(int Id)
        {
            var result = stdList.Where(o => o.Id == Id).FirstOrDefault();
            return result;
        }
    }
}
