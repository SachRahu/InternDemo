﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Storage.Blob;
using Storage.Queue;
using Storage.Table;
//using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.IO;
using System.Threading.Tasks;

namespace Storage
{
    class Program
    {
        /// ref url
        /// https://docs.microsoft.com/en-us/azure/cosmos-db/tutorial-develop-table-dotnet?toc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Fstorage%2Ftables%2Ftoc.json&bc=https%3A%2F%2Fdocs.microsoft.com%2Fen-us%2Fazure%2Fbread%2Ftoc.json
        ///https://docs.microsoft.com/en-us/azure/storage/blobs/storage-quickstart-blobs-dotnet-legacy
        ///https://docs.microsoft.com/en-us/rest/api/storageservices/understanding-block-blobs--append-blobs--and-page-blobs
        static async Task Main(string[] args)
        {
            //Blob
            var blobV11 = new BlobV11();
            await blobV11.UploadBlob();

            //var blobV12 = new BlobV12();
            //await blobV12.UploadBlob();

            //Table

            //TableSample tableSample = new TableSample();
            //await tableSample.RunSamples();

            //Queue
            //var queueStorage = new QueueStorage();
            //await queueStorage.Initialize();
            //for (int i = 0; i <= 100; i++)
            //{
            //    await queueStorage.AddMessage($"Hi-{i}");
            //    Console.WriteLine($"Message sent to the queue Hi-{i}");
            //}
            //await queueStorage.PeekedMessage();
            //await queueStorage.RetrievedMessage();
        }
    }
}
