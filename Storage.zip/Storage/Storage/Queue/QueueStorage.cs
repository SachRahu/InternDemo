﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Queue;
using System;
using System.Threading.Tasks;

namespace Storage.Queue
{
   public class QueueStorage
    {
        CloudQueue queue;
        CloudStorageAccount storageAccount;
        public QueueStorage()
        {
            string storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=demostorage55;AccountKey=BMb5p9lNdZkZDXaa1YndiDblUTMBp928osa5Z2RKT+vljF0x4YiRxUCU0WY4jI7wsXZvUEk/oY783x3pVIYTRg==;EndpointSuffix=core.windows.net";

            // Check whether the connection string can be parsed.
            if (CloudStorageAccount.TryParse(storageConnectionString, out storageAccount))
            {
                var client = storageAccount.CreateCloudQueueClient();
                queue = client.GetQueueReference("quickstartqueues");
                //await queue.CreateIfNotExistsAsync();

               
            }
            else
            {
                Console.WriteLine(
                    "A connection string has not been defined in the system environment variables. " +
                    "Add an environment variable named 'storageconnectionstring' with your storage " +
                    "connection string as a value.");
            }
        }

        public async Task<bool> Initialize()
        {
            return await queue.CreateIfNotExistsAsync();          
            
        }
        public async Task AddMessage(string message)
        {
            await queue.AddMessageAsync(new CloudQueueMessage(message));
        }

        public async Task PeekedMessage()
        {
            CloudQueueMessage peekedMessage = await queue.PeekMessageAsync();
            Console.WriteLine("Contents of peeked message '{0}': {1}", peekedMessage.Id, peekedMessage.AsString);
            Console.WriteLine();
        }

        public async Task RetrievedMessage()
        {
            CloudQueueMessage retrievedMessage = await queue.GetMessageAsync();

            Console.WriteLine(retrievedMessage.AsString);
           
            // Display the time at which the message will become visible again if it is not deleted.
            Console.WriteLine("Message '{0}' becomes visible again at {1}", retrievedMessage.Id, retrievedMessage.NextVisibleTime);
            Console.WriteLine();

            //Process and delete the message within the period of invisibility.
            await queue.DeleteMessageAsync(retrievedMessage);
            Console.WriteLine("Processed and deleted message '{0}'", retrievedMessage.Id);
            Console.WriteLine();
        }
    }
}
