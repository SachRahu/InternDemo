﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Storage.Blob
{
   public class BlobV11
    {
        public async Task UploadBlob()
        {
            string storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=demostorage55;AccountKey=BMb5p9lNdZkZDXaa1YndiDblUTMBp928osa5Z2RKT+vljF0x4YiRxUCU0WY4jI7wsXZvUEk/oY783x3pVIYTRg==;EndpointSuffix=core.windows.net";

            // Check whether the connection string can be parsed.
            CloudStorageAccount storageAccount;
            if (CloudStorageAccount.TryParse(storageConnectionString, out storageAccount))
            {
                // Create the CloudBlobClient that represents the 
                // Blob storage endpoint for the storage account.
                CloudBlobClient cloudBlobClient = storageAccount.CreateCloudBlobClient();

                // Create a container called 'quickstartblobs' and 
                // append a GUID value to it to make the name unique.
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference("quickstartblobs");
                await cloudBlobContainer.CreateIfNotExistsAsync();

                // Set the permissions so the blobs are public.
                BlobContainerPermissions permissions = new BlobContainerPermissions
                {
                    PublicAccess = BlobContainerPublicAccessType.Blob
                };
                await cloudBlobContainer.SetPermissionsAsync(permissions);

                await UploadBlockBlob(cloudBlobContainer);
                await UploadAppendBlob(cloudBlobContainer); 
            }
            else
            {
                // Otherwise, let the user know that they need to define the environment variable.
                Console.WriteLine(
                    "A connection string has not been defined in the system environment variables. " +
                    "Add an environment variable named 'AZURE_STORAGE_CONNECTION_STRING' with your storage " +
                    "connection string as a value.");
                Console.WriteLine("Press any key to exit the application.");
                Console.ReadLine();
            }

            
        }

        private async Task UploadAppendBlob(CloudBlobContainer cloudBlobContainer)
        {
            string fileName = "testAppend.txt";
            CloudAppendBlob blob = cloudBlobContainer.GetAppendBlobReference(fileName);
            if (!await blob.ExistsAsync())
            {
                await blob.CreateOrReplaceAsync();
            }

            using MemoryStream stream = new MemoryStream();
            using StreamWriter sw = new StreamWriter(stream);
            sw.Write("Test data 4");
            sw.Flush();
            stream.Position = 0;
            await blob.AppendFromStreamAsync(stream);
        }

        private async Task UploadBlockBlob(CloudBlobContainer cloudBlobContainer)
        {
            // Create a file in your local MyDocuments folder to upload to a blob.
            string localPath = "./data/";
            string localFileName = "blockblob.txt";
            string sourceFile = Path.Combine(localPath, localFileName);
            // Write text to the file.
            File.WriteAllText(sourceFile, "Hello, World Update!");

            Console.WriteLine("Temp file = {0}", sourceFile);
            Console.WriteLine("Uploading to Blob storage as blob '{0}'", localFileName);

            // Get a reference to the blob address, then upload the file to the blob.
            // Use the value of localFileName for the blob name.
            CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(localFileName);
            await cloudBlockBlob.UploadFromFileAsync(sourceFile);
        }
    }
}
