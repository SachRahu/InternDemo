﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace Storage.Blob
{
   public class BlobV12
    {
        public async Task UploadBlob()
        {
            var blobServiceClient = new BlobServiceClient("DefaultEndpointsProtocol=https;AccountName=demostorage55;AccountKey=BMb5p9lNdZkZDXaa1YndiDblUTMBp928osa5Z2RKT+vljF0x4YiRxUCU0WY4jI7wsXZvUEk/oY783x3pVIYTRg==;EndpointSuffix=core.windows.net");

            //Create a unique name for the container
            string containerName = "quickstartblobs";


            //var containerClient1 =  await blobServiceClient.
            BlobContainerClient containerClient = await blobServiceClient.CreateBlobContainerAsync(containerName);

            containerClient.SetAccessPolicy(PublicAccessType.BlobContainer);

            // Create a local file in the ./data/ directory for uploading and downloading
            string localPath = "./data/";
            string fileName = "quickstart" + Guid.NewGuid().ToString() + ".txt";
            string localFilePath = Path.Combine(localPath, fileName);

            await File.WriteAllTextAsync(localFilePath, "Hello, World!");

            // Get a reference to a blob
            BlobClient blobClient = containerClient.GetBlobClient(fileName);

            Console.WriteLine("Uploading to Blob storage as blob:\n\t {0}\n", blobClient.Uri);

            // Open the file and upload its data
            using FileStream uploadFileStream = File.OpenRead(localFilePath);
            await blobClient.UploadAsync(uploadFileStream, true);
            uploadFileStream.Close();
        }       
    }
}
